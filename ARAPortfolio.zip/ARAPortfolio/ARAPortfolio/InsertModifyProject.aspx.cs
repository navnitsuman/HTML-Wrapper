﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class InsertModifyProject : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            resetTemplate();
        }
    }
    private void resetTemplate()
    {
        ProjectIDHiddenField.Value = string.Empty;

        var dbConnect = new DBConnect();
        if (!dbConnect.OpenConnection()) return;

        //LOB
        var cmd = new SqlCommand("SELECT DISTINCT ID,LOB FROM dbo.BICC_ARAPortfolio_LOB Where IsActive=1", dbConnect.GetConnection());
        var dr = cmd.ExecuteReader();
        LOBNameDropDownList.Items.Clear();
        LOBNameDropDownList.Items.Add(new ListItem("----LOB----", "0"));
        while (dr.Read())
        {
            LOBNameDropDownList.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
        }
        dr.Close();

        //Priority
        cmd = new SqlCommand("SELECT DISTINCT ID,Priority FROM dbo.BICC_ARAPortfolio_Priority Where IsActive=1", dbConnect.GetConnection());
        dr = cmd.ExecuteReader();
        PriorityDropDownList.Items.Clear();
        PriorityDropDownList.Items.Add(new ListItem("----Priority----", "0"));
        while (dr.Read())
        {
            PriorityDropDownList.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
        }
        dr.Close();

        //Portfolio
        cmd = new SqlCommand("SELECT DISTINCT ID,Portfolio FROM dbo.BICC_ARAPortfolio_Portfolio Where IsActive=1", dbConnect.GetConnection());
        dr = cmd.ExecuteReader();
        PortfolioDropDownList.Items.Clear();
        PortfolioDropDownList.Items.Add(new ListItem("----Portfolio----", "0"));
        while (dr.Read())
        {
            PortfolioDropDownList.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
        }
        dr.Close();


        //Benefit Type
        cmd = new SqlCommand("SELECT DISTINCT ID,BenefitType FROM dbo.BICC_ARAPortfolio_BenefitType Where IsActive=1", dbConnect.GetConnection());
        dr = cmd.ExecuteReader();
        BenefitTypeDropDownList.Items.Clear();
        BenefitTypeDropDownList.Items.Add(new ListItem("----Benefit Type----", "0"));
        while (dr.Read())
        {
            BenefitTypeDropDownList.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
        }
        dr.Close();


        //Benefit Type
        cmd = new SqlCommand("SELECT DISTINCT ID,Status FROM dbo.BICC_ARAPortfolio_ProjectStatus Where IsActive=1", dbConnect.GetConnection());
        dr = cmd.ExecuteReader();
        CurrentStatusDropDownList.Items.Clear();
        CurrentStatusDropDownList.Items.Add(new ListItem("----Status----", "0"));
        while (dr.Read())
        {
            CurrentStatusDropDownList.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
        }
        dr.Close();

        //Resource Span
        cmd = new SqlCommand("SELECT DISTINCT ID,SpanName,[SpanLeaderNTID] FROM dbo.BICC_ARAPortfolio_SpanList Where IsActive=1", dbConnect.GetConnection());
        dr = cmd.ExecuteReader();
        ResourceSpanDropDownList.Items.Clear();
        ResourceSpanDropDownList.Items.Add(new ListItem("----Resource Span----", "0"));
        while (dr.Read())
        {
            ResourceSpanDropDownList.Items.Add(new ListItem(dr[1].ToString() + " ("+ dr[2].ToString()+")", dr[0].ToString()));
        }
        dr.Close();


        //Resource Work Location
        cmd = new SqlCommand("SELECT DISTINCT ID,[SiteCode],[SiteName] FROM dbo.BICC_ARAPortfolio_WorkLocationList Where IsActive=1", dbConnect.GetConnection());
        dr = cmd.ExecuteReader();
        ResourceWorkLocationDropDownList.Items.Clear();
        ResourceWorkLocationDropDownList.Items.Add(new ListItem("----Resource Work Location----", "0"));
        while (dr.Read())
        {
            ResourceWorkLocationDropDownList.Items.Add(new ListItem(dr[1].ToString() + " (" + dr[2].ToString() + ")", dr[0].ToString()));
        }
        dr.Close();



        dbConnect.CloseConnection();
    }

}